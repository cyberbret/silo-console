import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,t as n}from"./react-vendor-UL3KVrSx.js";import{T as r}from"./shared-vendor-BQfq49S_.js";import{i}from"./lang-CEXg5ouE.js";import{X as a}from"./mds-Br1NHt8T.js";import{t as o}from"./ModalBox-CLgFXgZ9.js";import{a as s}from"./i18n-BSlOk5KH.js";var c=e(t()),l=n(),u=r.dl`
  ${a(`body`)}
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 8px 20px;
  margin: 16px 0 0;
  dt {
    font-family: var(--font-mono);
    font-variant-numeric: tabular-nums;
  }
  dd {
    margin: 0;
    color: var(--muted-foreground);
  }
  @media (max-width: 600px) {
    grid-template-columns: 1fr;
    gap: 4px;
    dd {
      margin-bottom: 8px;
    }
  }
`,d=[[`↑ / ↓ · Home / End`,i(`Move through objects`)],[`PageUp / PageDown`,i(`Move one visible page`)],[`Enter`,i(`Open folder or object details`)],[`Backspace / Alt+↑`,i(`Go to parent folder within this bucket`)],[`Space`,i(`Toggle object selection`)],[`Shift+↑ / Shift+↓ · Shift+click`,i(`Extend selection range`)],[`Ctrl/⌘+click`,i(`Toggle object selection`)],[`Ctrl/⌘+A`,i(`Select all objects on the current page`)],[`Escape`,i(`Close menu, clear selection or close details`)],[`/`,i(`Focus object filter`)],[`p`,i(`Preview the focused object when available`)],[`Shift+F10 / ContextMenu`,i(`Open object actions`)],[`?`,i(`Keyboard shortcuts`)]];function f({onClose:e}){let t=s();return(0,l.jsxs)(o,{open:!0,title:t(`Keyboard shortcuts`),closeLabel:t(`Close`),onClose:e,size:`lg`,children:[(0,l.jsx)(`p`,{children:t(`Object browser shortcuts are available while browsing objects. They pause while typing or using a dialog.`)}),(0,l.jsx)(u,{children:d.map(([e,n])=>(0,l.jsxs)(c.Fragment,{children:[(0,l.jsx)(`dt`,{children:e}),(0,l.jsx)(`dd`,{children:t(n)})]},e))})]})}export{f as default};