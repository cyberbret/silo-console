import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,t as n}from"./react-vendor-UL3KVrSx.js";import{T as r}from"./shared-vendor-BQfq49S_.js";import{n as i}from"./lang-CEXg5ouE.js";import{t as a}from"./copy-Br4HbfKd.js";import{t as o}from"./code-nMrcKYmU.js";import{a as s}from"./i18n-BSlOk5KH.js";import{n as c,t as l}from"./shared-DNNv_4dQ.js";import{t as u}from"./typography-FIWfJMKK.js";import{t as d}from"./lib-BVN4wEer.js";var f=e(t()),p=e(d()),m=n(),h=r.details`
  ${u.body}
  border: 1px solid var(--silo-border);
  border-radius: var(--silo-radius-card);
  background: var(--silo-surface);
  color: var(--silo-text);
  overflow: hidden;
  summary {
    cursor: pointer;
    padding: var(--silo-space-16);
  }
  summary > span {
    display: inline-flex;
    align-items: center;
    gap: var(--silo-space-8);
    vertical-align: middle;
  }
  summary svg {
    width: 16px;
    height: 16px;
    fill: var(--silo-text-secondary);
    color: var(--silo-text-secondary);
  }
`,g=r.div`
  padding: 0 var(--silo-space-16) var(--silo-space-16);
`,_=r.div`
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: var(--silo-space-8);
  ${u.caption}
  color: var(--silo-text-secondary);
`,v=r.pre`
  ${u.small}
  font-family: var(--font-mono);
  background: var(--silo-bg);
  border: 1px solid var(--silo-border);
  border-radius: var(--silo-radius-input);
  padding: var(--silo-space-12);
  margin: var(--silo-space-8) 0;
  overflow-x: auto;
  white-space: pre;
  font-variant-numeric: tabular-nums;
`,y=r.p`
  ${u.caption} margin: 0;
  color: var(--silo-text-secondary);
`,b=({commands:e,alias:t,open:n,onToggle:r})=>{let u=s(),[d,b]=(0,f.useState)(null),x=e.join(`
`);return(0,f.useEffect)(()=>b(null),[x]),(0,f.useEffect)(()=>{if(d===null)return;let e=window.setTimeout(()=>b(null),3e3);return()=>window.clearTimeout(e)},[d]),(0,m.jsxs)(h,{open:n,onToggle:e=>r?.(e.currentTarget.open),children:[(0,m.jsx)(`summary`,{children:(0,m.jsxs)(`span`,{children:[(0,m.jsx)(o,{"aria-hidden":`true`}),u(`Equivalent mcli command`)]})}),(0,m.jsxs)(g,{children:[(0,m.jsxs)(_,{children:[(0,m.jsx)(`span`,{role:`status`,children:d===null?``:u(d?`Copied`:`Copy failed. Select and copy the command.`)}),(0,m.jsx)(p.CopyToClipboard,{text:x,onCopy:(e,t)=>b(t),children:(0,m.jsx)(`span`,{children:(0,m.jsx)(c,{text:u(`Copy commands`),children:(0,m.jsx)(l,{type:`button`,"aria-label":u(`Copy commands`),children:(0,m.jsx)(a,{"aria-hidden":`true`})})})})})]}),(0,m.jsx)(v,{tabIndex:0,children:(0,m.jsx)(`code`,{children:x})}),(0,m.jsx)(y,{children:t?i(u(`Replace ALIAS with your configured mcli alias (for example, {alias}).`),{alias:t}):u(`Replace ALIAS with your configured mcli alias.`)})]})]})};export{b as t};